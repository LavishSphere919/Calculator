import math
from fractions import Fraction as frac
print('Welcome to the Calculator!')
while True:
    operation = input('Please enter a command: ')
    if operation == 'addition':
        addendA = float(input('Please enter the first addend: '))
        addendB = float(input('Please enter the second addend: '))
        sum = addendA + addendB
        print('The sum for this problem is:', sum, '.')
    elif operation == 'division':
        divisor = float(input('Please enter the divisor: '))
        dividend = float(input('Please enter the dividend: '))
        quotient = divisor / dividend
        print('The quotient for this problem is:', quotient, '.')
    elif operation == 'multiplication':
        multiplier = float(input('Please enter the multipler: '))
        multiplicand = float(input('Please enter the multiplicand: '))
        product = multiplier * multiplicand
        print('The product for this problem is', product, '.')
    elif operation == "subtraction":
        minuend = float(input('Please enter the minuend: '))
        subtrahend = float(input('Please enter the subtrahend: '))
        difference = minuend - subtrahend
        print('The difference for this problem is', difference, '.')
    elif operation == "square root":
        num1 = float(input('Please enter a number to find the square root: '))
        root = math.sqrt(num1)
        print('The square root for this value is: ', root, '.')
    elif operation == "exponentiation":
        base = float(input('Please enter the base: '))
        exponent = float(input('Plese enter the exponent: '))
        answer = base**exponent
        print('The answer for this problem is:', answer, '.')
    elif operation == "percent-number":
        percentage = float(input('Please enter the percentage: '))
        numb = percentage / 100
        print('The number form for this problem is', numb, '.')
    elif operation == "fraction":
        numbe = input('Please enter the value: ')
        print(frac(numbe))
    elif operation == "info":
        print(
            "Created by: Ashsmith Khayrul Version: 1.0.0.0.0 Last updated: Friday, October 29th, 2021 at 1:25 PM PDT Python 3.8.2 Feb 26, 2020 02:56:10"
        )
    elif operation == "cube root":
        num = float(input('Please enter a number to find the cube root: '))
        root2 = num**(1 / 3)
        print('The cube root for this value is:', root2, '.')
    elif operation == "nth root":
        num2 = float(input('Please enter a number to find the nth root: '))
        nth = float(input('Please enter the nth root: '))
        root3 = num2**(1 / nth)
        print('The solution is:', root3, '.')
    elif operation == "number-percent":
        num0 = float(input('Please enter the number: '))
        percent = num0 * 100
        print('The percent form for this problem is', percent, '%.')
    else:
        print(
            'Configuration not found. Please enter one of the following for the value of command: [info, multiplication, division, addition, subtraction, percent-number, fraction, exponentiation, square root, cube root, nth root, or number-percent].'
        )
